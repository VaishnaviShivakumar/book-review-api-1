const express = require('express');
const router = express.Router();
const Book = require('../models/Book');
const Review = require('../models/Review');
const auth = require('../middleware/auth');

// Add new book (auth required)
router.post('/', auth, async (req, res) => {
  try {
    const { title, author, genre } = req.body;
    if (!title || !author || !genre) return res.status(400).json({ msg: 'Please enter all fields' });

    const book = new Book({ title, author, genre });
    await book.save();
    res.status(201).json(book);
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
});

// Get all books with filters and pagination
router.get('/', async (req, res) => {
  try {
    const { page = 1, limit = 10, author, genre } = req.query;
    const filter = {};
    if (author) filter.author = new RegExp(author, 'i');
    if (genre) filter.genre = new RegExp(genre, 'i');

    const books = await Book.find(filter)
      .skip((page - 1) * limit)
      .limit(parseInt(limit));

    res.json(books);
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
});

// Get book details by ID with average rating and paginated reviews
router.get('/:id', async (req, res) => {
  try {
    const book = await Book.findById(req.params.id);
    if (!book) return res.status(404).json({ msg: 'Book not found' });

    const { page = 1, limit = 5 } = req.query;

    const reviews = await Review.find({ bookId: book._id })
      .skip((page - 1) * limit)
      .limit(parseInt(limit))
      .populate('userId', 'username');

    const count = await Review.countDocuments({ bookId: book._id });

    const avgRatingAgg = await Review.aggregate([
      { $match: { bookId: book._id } },
      { $group: { _id: '$bookId', avgRating: { $avg: '$rating' } } },
    ]);
    const avgRating = avgRatingAgg[0] ? avgRatingAgg[0].avgRating : null;

    res.json({
      book,
      averageRating: avgRating,
      reviews,
      totalReviews: count,
      currentPage: parseInt(page),
      totalPages: Math.ceil(count / limit),
    });
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
});

// Submit review (auth required, one review per user per book)
router.post('/:id/reviews', auth, async (req, res) => {
  try {
    const { rating, comment } = req.body;
    if (!rating || rating < 1 || rating > 5) return res.status(400).json({ msg: 'Invalid rating' });

    const bookId = req.params.id;
    const userId = req.user.id;

    // Check if review exists
    const existingReview = await Review.findOne({ bookId, userId });
    if (existingReview) return res.status(400).json({ msg: 'You have already reviewed this book' });

    const review = new Review({ bookId, userId, rating, comment });
    await review.save();

    res.status(201).json(review);
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;
