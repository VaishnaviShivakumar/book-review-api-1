const express = require('express');
const router = express.Router();
const Review = require('../models/Review');
const auth = require('../middleware/auth');

// Update your own review
router.put('/:id', auth, async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);
    if (!review) return res.status(404).json({ msg: 'Review not found' });
    if (review.userId.toString() !== req.user.id) return res.status(401).json({ msg: 'Unauthorized' });

    const { rating, comment } = req.body;
    if (rating) {
      if (rating < 1 || rating > 5) return res.status(400).json({ msg: 'Invalid rating' });
      review.rating = rating;
    }
    if (comment) review.comment = comment;

    await review.save();
    res.json(review);
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
});

// Delete your own review
router.delete('/:id', auth, async (req, res) => {
  try {
    const review = await Review.findById(req.params.id);
    if (!review) return res.status(404).json({ msg: 'Review not found' });
    if (review.userId.toString() !== req.user.id) return res.status(401).json({ msg: 'Unauthorized' });

    await review.deleteOne();
    res.json({ msg: 'Review deleted' });
  } catch (err) {
    res.status(500).json({ msg: 'Server error' });
  }
});

module.exports = router;
