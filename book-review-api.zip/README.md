# Book Review API

This project is a RESTful API built with Node.js and Express.js that allows users to register, login, add books, submit reviews, and search books. Authentication is handled via JSON Web Tokens (JWT).

## Setup Instructions

1. Clone the repo
2. Run `npm install` to install dependencies
3. Create a `.env` file based on `.env.example`
4. Run MongoDB locally or use a cloud MongoDB connection string
5. Start the server using `npm run dev`

## API Endpoints

- `POST /api/signup` - Register new user
- `POST /api/login` - Login user and get JWT
- `POST /api/books` - Add a book (auth required)
- `GET /api/books` - Get all books with filters and pagination
- `GET /api/books/:id` - Get book details with reviews and average rating
- `POST /api/books/:id/reviews` - Add a review (auth required)
- `PUT /api/reviews/:id` - Update review (auth required)
- `DELETE /api/reviews/:id` - Delete review (auth required)
- `GET /api/search?q=term` - Search books by title or author
